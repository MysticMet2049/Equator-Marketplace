export { default } from "../StoreDetailPageContent";
